﻿using Microsoft.Maui.Controls;

namespace MAUIDMSMobile
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
