﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDMSMobile.Mvvm.Models.Odata4
{
    public class ApiResponseHistorique
    {
        public List<HistoriqueRendezVousOdata> value { get; set; }

    }
}
