﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDMSMobile.Mvvm.Models.Odata4
{
    public class ApiResponseCenter
    {
        public List<ServiceCenterOdata> value { get; set; }
    }

}
