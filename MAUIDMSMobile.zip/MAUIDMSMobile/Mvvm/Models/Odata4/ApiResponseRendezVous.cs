﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDMSMobile.Mvvm.Models.Odata4
{
    public class ApiResponseRendezVous
    {
        public List<GetRendezVous> value { get; set; }

    }
}
