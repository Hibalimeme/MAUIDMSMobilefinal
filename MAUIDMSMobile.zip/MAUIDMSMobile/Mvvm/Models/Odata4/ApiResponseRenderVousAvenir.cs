﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDMSMobile.Mvvm.Models.Odata4
{
    public class ApiResponseRenderVousAvenir
    {
        public List<RendezVousAvenirModelOdata> value { get; set; }
    }
}
