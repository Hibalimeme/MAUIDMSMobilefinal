﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDMSMobile.Mvvm.Models
{
    public class marquemodel
    {
        public string model { get; set; }
        public string marque { get; set; }
       
    }
}
