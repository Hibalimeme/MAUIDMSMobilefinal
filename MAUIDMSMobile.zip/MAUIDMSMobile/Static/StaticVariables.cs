﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MAUIDMSMobile.Mvvm.Models;

namespace MAUIDMSMobile.Static
{
    public static class StaticVariables
    {
        public static UtilisateurLogin CurrentUser { get; set; } = new UtilisateurLogin();


    }
}
