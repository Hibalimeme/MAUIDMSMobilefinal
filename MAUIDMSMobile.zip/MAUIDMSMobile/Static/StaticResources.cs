﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUIDMSMobile.Static
{
    public static class StaticResources
    {
        public static string strLogin = "Se Connecter ";
        public static string strNumero = "Numero"; 
        public static string strpassword = "mot de passe ";
        public static string strmpoublié = "Mot de passe oublié";
        public static string Strmiseajour = "Mise a jour "; 
        public static string Strlangue = "langue ";
        public static string Strfrancais = "francais "; 
        public static string Strenglais = "anglais ";
        public static string Strarab  = "arab ";
        public static string Strhomme  = "homme ";
        public static string Strfemme  = "femme ";

        public static string strSesouvenir  = "Se souvenir de moi";
        public static string strConnexion = "Connexion";
        public static string strpasdecompte = "Vous n'avez pas de compte ?";
        public static string strCréeruncompte = "Créer un compte";
        public static string strcreation = "Creation de compte";
        public static string strprenom = "Prénom";
        public static string strgenre = "Sélectionner le genre"; 
        public static string stremail = "Email"; 
        public static string strPays = "Pays"; 
        public static string strVille = "Ville"; 
        public static string strCodepostal = "Code postal";
        public static string strAdresse = "Adresse";
        public static string strcompte = "Vous avez de compte ?";
        public static string strCode = "Code postal";

    }
}
